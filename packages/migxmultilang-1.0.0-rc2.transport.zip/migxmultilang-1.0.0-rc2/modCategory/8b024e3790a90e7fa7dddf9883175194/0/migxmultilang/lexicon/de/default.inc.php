<?php
/**
 * migxmultilang
 *
 * @package migxmultilang
 * @language en
 */

//$_lang['mig_'] = '';

$_lang['mml.language'] = 'Sprache';
$_lang['mml.import_example_config'] = 'Konfigurationen importieren';
$_lang['mml.add_config'] = 'Formtabs Konfiguration erstellen';
$_lang['mml.create_tvs'] = 'TVs erstellen';
$_lang['mml.published'] = 'Veröffentlicht';
$_lang['mml.to_translate'] = 'Zu Übersetzen';
$_lang['mml.specific_templates'] = 'Spezifische Templates';
$_lang['mml.specific_templates_desc'] = 'Jedem Template kann nur eine Konfiguration zugewiesen werden. Zuweisen zu einem Template entfernt alle anderen Konfigurationen von diesem!';
$_lang['mml.use_as_default_formtabs'] = 'Als Standard Konfiguration für alle anderen Templates verwenden';