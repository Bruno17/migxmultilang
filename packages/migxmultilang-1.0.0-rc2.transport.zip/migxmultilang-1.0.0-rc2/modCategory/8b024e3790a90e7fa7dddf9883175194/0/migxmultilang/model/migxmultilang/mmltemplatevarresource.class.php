<?php
class mmlTemplateVarResource extends xPDOSimpleObject {}