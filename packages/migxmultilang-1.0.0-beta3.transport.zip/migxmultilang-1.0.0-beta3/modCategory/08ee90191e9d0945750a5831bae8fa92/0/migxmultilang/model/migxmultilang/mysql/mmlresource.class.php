<?php
require_once (dirname(dirname(__FILE__)) . '/mmlresource.class.php');
class mmlResource_mysql extends mmlResource {}