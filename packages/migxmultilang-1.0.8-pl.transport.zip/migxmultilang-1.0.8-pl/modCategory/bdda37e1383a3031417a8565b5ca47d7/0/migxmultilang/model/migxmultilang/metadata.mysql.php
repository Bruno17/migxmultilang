<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'mmlLang',
    1 => 'mmlTemplateVarResource',
    2 => 'mmlFormtabs',
    3 => 'mmlFormtabsTemplate',
  ),
  'modResource' => 
  array (
    0 => 'mmlResource',
  ),
);