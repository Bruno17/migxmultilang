<?php

require MODX_CORE_PATH . 'components/migxmultilang/model/migxmultilang/mmlfetch.class.php';