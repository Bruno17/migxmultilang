<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'mmlLang',
    1 => 'mmlTemplateVarResource',
  ),
  'modResource' => 
  array (
    0 => 'mmlResource',
  ),
);