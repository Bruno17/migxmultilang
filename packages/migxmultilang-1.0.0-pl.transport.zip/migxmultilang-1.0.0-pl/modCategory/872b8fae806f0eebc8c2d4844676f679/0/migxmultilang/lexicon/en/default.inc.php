<?php
/**
 * migxmultilang
 *
 * @package migxmultilang
 * @language en
 */

//$_lang['mig_'] = '';

$_lang['mml.language'] = 'Language';
$_lang['mml.import_example_config'] = 'Import Configurations';
$_lang['mml.add_config'] = 'Add Formtabs Configuration';
$_lang['mml.create_tvs'] = 'Create TVs';
$_lang['mml.published'] = 'Published';
$_lang['mml.to_translate'] = 'To translate';
$_lang['mml.specific_templates'] = 'Specific Templates';
$_lang['mml.specific_templates_desc'] = 'Each Template can have only one language-formtabs. This does remove selected templates from other formtabs!';
$_lang['mml.use_as_default_formtabs'] = 'Use as Default Formtabs for all other templates';
$_lang['mml.hide_default_lang'] = 'Hide default language from Translations - grid';
$_lang['mml.hide_default_lang_fields'] = 'Hide some fields from default language';
$_lang['mml.hide_default_lang_fields_desc'] = 'Comma - separated list of fieldnames';
$_lang['mml.order_position'] = 'Position';