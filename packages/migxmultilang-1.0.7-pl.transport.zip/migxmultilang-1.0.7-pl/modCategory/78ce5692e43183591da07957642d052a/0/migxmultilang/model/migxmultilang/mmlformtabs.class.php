<?php
class mmlFormtabs extends xPDOSimpleObject {}