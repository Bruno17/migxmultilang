<?php
//[[!mml_LangLinks]]

return $modx->runSnippet('mmlLangLinks',$scriptProperties);