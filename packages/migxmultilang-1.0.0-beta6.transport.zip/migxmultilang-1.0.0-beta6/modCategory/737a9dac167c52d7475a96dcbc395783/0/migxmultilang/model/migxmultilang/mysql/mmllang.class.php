<?php
require_once (dirname(dirname(__FILE__)) . '/mmllang.class.php');
class mmlLang_mysql extends mmlLang {}