<?php
require_once (dirname(dirname(__FILE__)) . '/mmltemplatevarresource.class.php');
class mmlTemplateVarResource_mysql extends mmlTemplateVarResource {}