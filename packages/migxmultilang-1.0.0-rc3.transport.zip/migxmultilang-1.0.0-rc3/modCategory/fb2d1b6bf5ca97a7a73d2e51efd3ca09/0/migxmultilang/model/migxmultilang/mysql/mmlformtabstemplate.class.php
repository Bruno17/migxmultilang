<?php
require_once (dirname(dirname(__FILE__)) . '/mmlformtabstemplate.class.php');
class mmlFormtabsTemplate_mysql extends mmlFormtabsTemplate {}