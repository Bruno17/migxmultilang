<?php
class mmlFormtabsTemplate extends xPDOSimpleObject {}