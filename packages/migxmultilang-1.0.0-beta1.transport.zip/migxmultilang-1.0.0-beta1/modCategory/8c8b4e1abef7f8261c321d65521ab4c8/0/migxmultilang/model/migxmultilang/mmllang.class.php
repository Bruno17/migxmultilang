<?php
class mmlLang extends xPDOSimpleObject {}