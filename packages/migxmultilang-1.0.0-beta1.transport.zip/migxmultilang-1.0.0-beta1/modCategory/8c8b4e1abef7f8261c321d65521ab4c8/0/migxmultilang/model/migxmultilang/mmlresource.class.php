<?php
class mmlResource extends modResource {}