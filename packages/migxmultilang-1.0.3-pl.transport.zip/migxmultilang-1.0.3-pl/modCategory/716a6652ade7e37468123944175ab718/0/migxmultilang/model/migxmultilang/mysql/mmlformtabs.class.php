<?php
require_once (dirname(dirname(__FILE__)) . '/mmlformtabs.class.php');
class mmlFormtabs_mysql extends mmlFormtabs {}